import type { VercelRequest, VercelResponse } from '@vercel/node';
import { getDb } from './db.js';

export default async function handler(
  req: VercelRequest,
  res: VercelResponse
) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const db = getDb();
    const { userId } = req.query;

    if (!userId) {
      return res.status(400).json({ error: 'userId is required' });
    }

    const parsedUserId = parseInt(userId as string);

    // Fetch friend user IDs and their details using a JOIN
    const result = await db.query(`
      SELECT b.user_id, b.username, b.first_name, b.last_name
      FROM user_connections c
      JOIN bot_users b ON c.user_id_2 = b.user_id
      WHERE c.user_id_1 = $1
      ORDER BY b.first_name ASC
    `, [parsedUserId]);

    const contacts = result.rows.map((u: any) => ({
      userId: u.user_id,
      username: u.username,
      firstName: u.first_name,
      lastName: u.last_name,
    }));

    return res.status(200).json(contacts);
  } catch (error) {
    console.error('[CONTACTS] Error:', error);
    return res.status(500).json({
      error: 'Internal server error',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
}
